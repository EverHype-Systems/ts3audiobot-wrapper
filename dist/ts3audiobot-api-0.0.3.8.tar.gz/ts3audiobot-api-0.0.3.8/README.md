# TS3AudioBot - API WRAPPER
**Installation:**
pip install ts3audiobot
